#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <zconf.h>
#include "shmem.h"

int main(void)
{
  Message *msgptr; // Сообщение.
  key_t key; // Ключ.

  int shmid, semid; // Идентификаторы семафора и разделяемой памяти.
  // Получение ключа.
  // ftok - преобразовывает имя файла и идентификатор проекта в ключ для системных вызовов.
  if ((key = ftok("file.txt", 'A')) < 0) {
    printf("Client: can't get a key\n"); // Ошибка получения ключа.
    exit(-1);
  }

  // Получение доступа к разделяемой памяти.
  // shmget - присваивает идентификатор разделяемому сегменту памяти.
  if ((shmid = shmget(key, sizeof(Message), 0)) < 0) {
    printf("Client: access denied\n");
    exit(-1);
  }

  // Присоединение разделяемой памяти.
  // Функция shmat подстыковывает сегмент разделяемой памяти shmid к адресному пространству вызывающего процесса.
  if ((msgptr = (Message *) shmat(shmid, 0, 0)) < 0) {
    printf("Client : error of joining\n");
    exit(-1);
  }
  // Получение доступа к семафору.
  // semget - считывает идентификатор набора семафоров.
  if ((semid = semget(key, 2, PERM)) < 0) {
    printf("Client: access denied\n");
    exit(-1);
  }
  // Блокировка разделяемой памяти.
  if (semop(semid, &mem_lock[0], 2) < 0) {
    printf("Client : can't execute a operation\n");
    exit(-1);
  }
  // Уведомление сервера о начале работы.
  if (semop(semid, &proc_start[0], 1) < 0) {
    printf("Client : can't execute a operation\n");
    exit(-1);
  }

  // Запись сообщения в разделяемую память.
  sprintf(msgptr->buff, "Message from client with PID = %d\n", getpid());
  // Освобождение ресурса.

  // Операция над семафором.
  if (semop(semid,&mem_unlock[0], 1) < 0) {
    printf("Client: can't execute a operation\n");
    exit(-1);
  }

sleep(1);
  
  // Ожидание завершения работы сервера с разделяемой памятью.
  if (semop(semid, &mem_lock[0], 2) < 0) {
    printf("Client: can't execute a operation\n");
    exit(-1);
  }

  // Чтение сообщения из разделяемой памяти.
  printf("Client: read message\n%s", msgptr->buff);
  // Освобождение разделяемой памяти.
  // Операция над семафором.
  if (semop(semid, &mem_unlock[0], 1) < 0) {
    printf("Client: can't execute a operation\n");
    exit(-1);
  }
  // Отключение от области разделяемой памяти.
  // Функция shmdt отстыковывает сегмент разделяемой памяти.
  if (shmdt(msgptr) < 0) {
    printf("Client: error\n");
    exit(-1);
  }
}