#include <semaphore.h>
#include <pthread.h>
#include <stdlib.h>
#include <printf.h>

#define NBUFF 5

struct {
  int buff[NBUFF];
  sem_t *mutex, *nempty, *nstored;
} shared;

int nitems = NBUFF * 2;

void *produce(void *), *consume(void *);


int main(int argc, char **argv) {
  pthread_t tid_produce, tid_consume;
// создание трех семафоров
 (shared.mutex = sem_open("/mutex", O_CREAT, 0777, 1));
 (shared.nempty = sem_open("/nempty", O_CREAT, 0777, NBUFF));
 (shared.nstored = sem_open("/nstored", O_CREAT, 0777, 0));

  pthread_create(&tid_produce, NULL, produce, NULL);
  pthread_create(&tid_consume, NULL, consume, NULL);
  pthread_join(tid_produce, NULL);
  pthread_join(tid_consume, NULL);

  sem_unlink("/mutex");
  sem_unlink("/nempty");
  sem_unlink("/nstored");
  exit(0);
}

void *produce(void *arg) {
  int i;
  for(i=0; i < nitems; i++) {
    sem_wait(shared.nempty);
    sem_wait(shared.mutex);

shared.buff[i%NBUFF] = i;
printf("producer - %i \n", shared.buff[i%NBUFF]);

sem_post(shared.mutex);
sem_post(shared.nstored);
  }
  return(NULL);
}


void *consume(void *arg) {
  int i;
  for(i=0; i<nitems; i++) {
    sem_wait(shared.nstored);
    sem_wait(shared.mutex);
// ожидаем появления объекта в буфере

    printf("consumer - %i \n", shared.buff[i%NBUFF]);
    shared.buff[i%NBUFF] = 0;
    sem_post(shared.mutex);
    sem_post(shared.nempty);
  }
  return(NULL);
}