﻿#include "list.h"
#include <stdio.h>
#include <windows.h>

const int N = 3; // Количество структур.
int current = 0; // Номер текущей.

Person people[N] {
	{"Vasiliy", 20, "male"},
	{"Anna", 25, "female"},
	{"Petr", 21, "Attack Helicopter"}
};

// Производитель.
DWORD WINAPI Producer(LPVOID lpParameter)
{
	// Узнаем у мьютекста, как дела.
	DWORD dw = WaitForSingleObject(hNextThreadEvent, INFINITE);
	// Бесконечно ждем мьютекс.
	while (TRUE)
	{
		if (current == N) {
			printf("Struct is full!\n");
			SetEvent(hNextThreadEvent);
			Sleep(100); // Ждем.
			DWORD dw = WaitForSingleObject(hNextThreadEvent, INFINITE);
			continue;
		}
		Sleep(1000);
		printf("Struct isn't full!\n");
		// Вставили человека в "базу".
		printf("Inserted: %s, %d years old, %s\n", people[current].name, people[current].age, people[current].sex);
		current++;
	}
}

// Потребитель.
DWORD WINAPI Consumer(LPVOID lpParameter)
{
	// Узнаем у мьютекста, как дела.
	DWORD dw = WaitForSingleObject(hNextThreadEvent, INFINITE);
	// Бесконечно ждем мьютекс.
	while (TRUE)
	{
		if (current == 0) {
			printf("Struct is empty!\n");
			SetEvent(hNextThreadEvent);
			Sleep(100); // Ждем.
			DWORD dw = WaitForSingleObject(hNextThreadEvent, INFINITE);
			continue;
		}
		Sleep(1000);
		printf("Struct isn't empty!\n");
		// Считываем человека из "базы".
		printf("Deleted: %s, %d years old, %s\n", people[current - 1].name, people[current - 1].age, people[current - 1].sex);
		current--;
	}
}