#include <windows.h>
#include <stdio.h>
#include <string.h>

STARTUPINFO startInfo;
PROCESS_INFORMATION processInfo;

int main(int argc, char* argv[])
{
	ZeroMemory(&startInfo, sizeof(STARTUPINFO));
	startInfo.cb = sizeof(startInfo);

	FILE* in = fopen("processes.txt", "r");
	if (in == NULL) {
		printf("Unable to read file processes.txt\n");
		return 1;
	}
	int processesNumber = 0;
	fscanf(in, "%d\n", &processesNumber);
	if (processesNumber < 1) {
		printf("Number of processes was too small\n");
		return 2;
	}

	const int size = 256;
	WCHAR proc_name[size];
	for (int i = 0; i < processesNumber; i++) {
		fgetws(proc_name, size, in);
		proc_name[wcscspn(proc_name, L"\n")] = 0;
		printf("!!!%ls %d\n", proc_name, wcslen(proc_name));
		
		if (!CreateProcess(NULL, proc_name, NULL, NULL, FALSE,
			HIGH_PRIORITY_CLASS | CREATE_NEW_CONSOLE, NULL, NULL,
			&startInfo, &processInfo)) {
			fprintf(stderr, "CreateProcess failed on error %d\n", GetLastError());
			ExitProcess(1);
		}
		Sleep(2000);
		TerminateProcess(processInfo.hProcess, 0);
	}

	printf("ProcessHandle=%d\n", (int)processInfo.hProcess);
	printf("ThreadHandle=%d\n", (int)processInfo.hThread);

	fclose(in);

	CloseHandle(processInfo.hProcess);
	CloseHandle(processInfo.hThread);

	return 0;
}