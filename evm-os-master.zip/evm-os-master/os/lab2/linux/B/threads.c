#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#define MAXTHREADS 4 // Количество потоков.

void *produce(void *arg); // Работа потока.

int main(void)
{
	int i;
	pthread_t tid_produce[MAXTHREADS]; // Массив инентификаторов потоков.
	for (i = 0; i < MAXTHREADS; i++)
	{
		// Если не удалось создать поток.
		if (pthread_create(&tid_produce[i], NULL, produce, &i) != 0)
		{
			printf("Couldn't create pthread!\n");
			exit(0);
		}
		sleep(1);
	}

	for (i = 0; i < MAXTHREADS; i++)
	{
		// Ожидание завершения порожденного потка.
		pthread_join(tid_produce[i], NULL);
	}
	exit(0);
}

void *produce(void *arg)
{
	int number = *(int *)arg; // Принимаем переменную, как int.
	int count = 0; // Локальная переменная.
	while (1)
	{
		printf("Hello I am Thread %d witn count %d\n", number, count);
		count++;
		sleep(5);
	}
	return (NULL);
}
