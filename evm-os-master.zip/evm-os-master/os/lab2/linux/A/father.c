#include <stdio.h>

main(int argc, char *argv[])
{
  int pid, ppid, status;                                    // id процесса, родителя процеса и статус процесса.
  pid = getpid();                                           // Получить id процесса.
  ppid = getppid();                                         // Получить id родителя процесса.
  printf("\n\nFATHER PARAM: pid=%i ppid=%i \n", pid, ppid); // Вывод.

  // Порождаем новый процесс.
  if (fork() == 0) // Если выполняется потомок копии.
  {
    execl("son", NULL); // Выполняем сына.
  }
  else
  {
    printf("%s", "I am biological father!\n");
  }

  if (argv[1][0] == '1')
  {
    wait(&status);
    printf("%s", "I waited for my son!\n");
    system("ps -xf > file1");
  }
  else if (argv[1][0] == '2')
  {
    system("ps -xf > file2");
  }
  else if (argv[1][0] == '3')
  {
    sleep(5);
    system("ps -xf > file3");
  }
}
