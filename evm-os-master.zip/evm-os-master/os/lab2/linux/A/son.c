#include <stdio.h>

main(){
  int pid,ppid; // id процесса, родителя процесса.
  pid=getpid(); // Получить id процесса.
  ppid=getppid(); // Получить id родителя процесса.
  printf("\nSON PARAM: pid=%i ppid=%i \n",pid,ppid);
  sleep(2);
  pid=getpid();
  ppid=getppid();
  printf("\nSON PARAM: pid=%i ppid=%i \n",pid,ppid);
}

